print("Introduce un numero para saber si es par o impar")
print("Ingresa un numero")

if let entrada = readLine(), let numero = Int(entrada) {
    if numero % 2 == 0 {
        print("El numero \(numero) es par")
    } else {
        print("El numero \(numero) es impar")
    }
} else {
    print("No ingresaste un numero valido")
}
  
